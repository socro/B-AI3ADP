package implementations.tests;

public class AdtAllTest {
    
}
