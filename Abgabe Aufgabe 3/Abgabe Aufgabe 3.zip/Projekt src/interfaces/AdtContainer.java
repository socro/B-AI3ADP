package interfaces;

public interface AdtContainer {
    
}
